import os
os.rename("C:/Users/karthik/Desktop/sample.txt","C:/Users/karthik/Desktop/sample1.txt")
