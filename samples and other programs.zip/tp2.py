n=int(input("Enter number:"))
n=str(n)
temp=1
for i in n:
    r=int(i)
    temp=temp*r
print(temp)
