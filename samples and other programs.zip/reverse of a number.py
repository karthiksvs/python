input_string = input("Enter a list element separated by space ")
list  = input_string.split()
print("Calculating sum of element of input list")
sum = 0
list.reverse()
print("Sum = ",list)
list.sort()
print(list)
