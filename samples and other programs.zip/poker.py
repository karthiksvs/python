def is_flush(hand):
  cards = hand.split()
  for card_index in range(len(cards) - 1):
    if cards[card_index][1] != cards[card_index + 1][1]:
      return False
  return True

def is_straight(hand):
  cards = hand.split()
  card_rank = []
  for card in cards:
    if card[0] == "A":
      card_rank.append(14)
    elif card[0] == "K":
      card_rank.append(13)
    elif card[0] == "Q":
      card_rank.append(12)
    elif card[0] == "J":
      card_rank.append(11)
    elif card[0] == "T":
      card_rank.append(10)
    else:
      card_rank.append(int(card[0]))
  card_rank.sort(reverse = True) # sorting in descending order
  for index in range(len(card_rank) - 1):
    if card_rank[index] - card_rank[index + 1] != 1: # since we sorted in descending order no abs() required.
      return False
  return True

def hand_rank(hand):
      card_dic = {}
      cards = hand.split()
      for card in cards:
        if card[0] in card_dic:
          card_dic[card[0]] += 1
        else:
          card_dic[card[0]] = 1
      rank_list = [card_dic[rank] for rank in card_dic]
      if is_straight(hand) and is_flush(hand):
        if "A" in hand: # royal flush
          print(hand, 10)
          return 10
        else: # straight flush
          print(hand, 9)
          return 9
      elif 4 in rank_list: # 4 of a kind
        print(hand, 8)
        return 8
      elif 3 in rank_list and 2 in rank_list: # full house
        print(hand, 7)
        return 7
      elif is_flush(hand): # flush
        print(hand, 6)
        return 6
      elif is_straight(hand): # straight
        print(hand, 5)
        return 5
      elif 3 in rank_list: # 3 of a kind
        print(hand, 4)
        return 4
      elif rank_list.count(2) == 2: # 2 pair
        print(hand, 3)
        return 3
      elif rank_list.count(2) == 1: # 1 pair
        print(hand, 2)
        return 2
      else: # high card
        print(hand, 1)
        return 1

def poker(hands):
  return (max(hands, key=hand_rank))


assert poker(['2D 3S 5S 4C 6D','3H 9S 7H TC KD','AH 3H 9H 5H QH', 'AD KD TD JD QD']) == 'AD KD TD JD QD'
assert poker(['2D 3S 5S 4C 6D', '2D 7D 3D JD QD', '3H 9S 7H TC KD', '5S 8C 2H 9C 3S']) == '2D 7D 3D JD QD'
assert poker(['2D 3S 5S 4C 6D', '3H 9S 7H TC KD', 'QH 2H 4H QS KS']) == '2D 3S 5S 4C 6D'
assert poker(['2D 9C AS AH AC', '3D 6D 7D TD QD']) == '3D 6D 7D TD QD'
assert poker(['3S 5C 9D 6H 8D', '4C 7D TC 7C TD']) == '4C 7D TC 7C TD'
assert poker(['AD 2S QD 2C JC', '6C AH 7S 7H 7D']) == '6C AH 7S 7H 7D'
assert poker(['3D 5S 6S 9S 4C', 'QS 8D QD 8S TC']) == 'QS 8D QD 8S TC'
assert poker(['2H 2D 4C 4D AS', '3C 3D 3S 9S 9D']) == '3C 3D 3S 9S 9D'
assert poker(['9S 9C 7D 9H 9S', 'KC 5S AD 4S 7D']) == '9S 9C 7D 9H 9S'
assert poker(['2H 2D 4C 4D 4S', '3C 3D 3S 9S 9D']) == '2H 2D 4C 4D 4S'
assert poker(['3D 4D 5D 6D 7D', '2H 3H 4H 5H 6H']) == '3D 4D 5D 6D 7D'
assert poker(['TS JS QS KS AH', 'TC JC QC KC AC']) == 'TC JC QC KC AC'
assert poker(['AS KD 3D JD 8H', '7C 8C 5C QD 6C']) == 'AS KD 3D JD 8H'
assert poker(['AS 2S 3S 4S 5S', 'TH KH JH AH QH']) == 'TH KH JH AH QH'
assert poker(['TD 3S 5H 4D 6S', '2D 5D 6H 4H TC']) == 'TD 3S 5H 4D 6S'
assert poker(['AD 2S 3H 4D 5S', 'KD 5D 6H 2H 9C']) == 'AD 2S 3H 4D 5S'
#assert poker(['5H 5C 6S 7S KD','2C 3S 8S 8D TD']) == '2C 3S 8S 8D TD'
#assert poker(['KC 9H 8D 5H 7H', '4H QC 3D 7C AS']) == '4H QC 3D 7C AS'
#assert poker(['KD TC JD 4H 3S', '5C 4C AS 7D JH']) == '5C 4C AS 7D JH'
print("Poker testcases passed!")

