from array import *
X = []
Y = []
result = []
for m in range(0,3):
    for n in range(0,3):
        print("Enter X input")
        w=input()
        X.append(w)
print(X)
for p in range(0,3):
    for q in range(0,3):
        print("Enter Y input")
        r=input()
        Y.append(r)
print(Y)
for i in range(len(X)):
   for j in range(len(Y)):
       for k in range(len(Y)):
           result[i][j] += X[i][k] * Y[k][j]
           result.append(result[i][j])
           print(result[i][j])
for r in result:
   print(r)
