#Bob was writing a document and suddenly the computer got power off. When he switched on later he could not find the text in the document, he was sad as he lost the all the information in the document.

#Luckily the text editor has a useful feature called "Word dictionary". This feature saves each word's frequency and the position of its occurences. By using this feature help Bob to recover his document by placing the words in the correct postion separated by spaces.

#A sample data in the Word indexes is below:

#Word dictionary = {'You': [1, [1]], 'cannot': [1, [2]], 'end': [1, [3]], 'a': [2, [4, 11]], 'sentence': [1, [5]], 'with': [1, [6]], 'because': [3, [7, 8, 9]], 'is': [1, [10]], 'conjunction': [1, [12]]}

#Output :  "You cannot end a sentence with because because because is a conjunction"
#Explanation : In the word dictionary, each word is key and the value is a list. In the value the first element is the count of occurence of that word in the text and the second element is the postions in which that word occurs. "You" has occured 1 time and its is in 1 position. "cannot" has occured 1 time and its position is 2 and so on.

#Word dictionary = {'That': [1, [1]], 'that': [3, [2, 5, 6]], 'is': [4, [3, 4, 7, 9]], 'not': [2, [8, 10]]}

#Output : "That that is is that that is not is not"




def regenerate_doc(word_dictionary):
  lst=[]
  str=""
  for index in word_dictionary:
      lst.append(word_dictionary[index])
  lst[0[1]]=word_dictionary[0]
  print(lst)
  return str
    
  #code
  
  
assert regenerate_doc({'That': [1, [1]], 'that': [3, [2, 5, 6]], 'is': [4, [3, 4, 7, 9]], 'not': [2, [8, 10]]}) =="That that is is that that is not is not"
assert regenerate_doc( {'You': [1, [1]], 'cannot': [1, [2]], 'end': [1, [3]], 'a': [2, [4, 11]], 'sentence': [1, [5]], 'with': [1, [6]], 'because': [3, [7, 8, 9]], 'is': [1, [10]], 'conjunction': [1, [12]]}) == "You cannot end a sentence with because because because is a conjunction"
assert regenerate_doc({'She': [1, [1]], 'was': [1, [2]], 'young': [3, [3, 8, 11]], 'the': [1, [4]], 'way': [1, [5]], 'an': [1, [6]], 'actual': [1, [7]], 'person': [1, [9]], 'is': [1, [10]]}) == "She was young the way an actual young person is young"
assert regenerate_doc({'Even': [1, [1]], 'if': [1, [2]], 'they': [1, [3]], 'are': [1, [4]], 'djinns,': [1, [5]], 'I': [1, [6]], 'will': [1, [7]], 'get': [1, [8]], 'djinns': [1, [9]], 'that': [1, [10]], 'can': [1, [11]], 'outdjinn': [1, [12]], 'them': [1, [13]]})== "Even if they are djinns, I will get djinns that can outdjinn them"
assert regenerate_doc({'I': [5, [1, 5, 13, 15, 20]], 'felt': [1, [2]], 'happy': [3, [3, 10, 23]], 'because': [2, [4, 12]], 'saw': [1, [6]], 'the': [1, [7]], 'others': [1, [8]], 'were': [1, [9]], 'and': [1, [11]], 'knew': [1, [14]], 'should': [1, [16]], 'feel': [1, [17]], 'happy,': [1, [18]], 'but': [1, [19]], 'wasn’t': [1, [21]], 'really': [1, [22]]}) == "I felt happy because I saw the others were happy and because I knew I should feel happy, but I wasn’t really happy"
print(" All testcases are passed")
