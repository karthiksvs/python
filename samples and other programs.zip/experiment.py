num1=int(input("Enter a number1:"))
num2=int(input("Enter a number2:"))
try:
    num3=num1/num2
except:
    print("You cant divide by zero")
else:
    print(num3)
