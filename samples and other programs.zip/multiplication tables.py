num=int(input("enter any number:"))
for i in range(1,11):
    print(num,"*",i,"=",num*i)
