dict={"a":1,"b":3,"c":5}
z=max(dict)
y=min(dict)
print(z,dict[z])
print(y,dict[y])
x={}
x=sorted(dict)
print(x)
