print("Enter input")
a=int(input())
b=int(a%10)
c=int(a/10)

while b!=0:
    print(b)
    b=int(c%10)
    c=int(c/10)
print(" reverse completed")
    
