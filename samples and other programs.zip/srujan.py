s='srujan'
l=[]
for c in s:
    l.append(c)

for i in range(len(l)):
    if(l[i]=='j'):
        print(i)
    
