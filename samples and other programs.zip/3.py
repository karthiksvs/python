def frequency_counter(text):
    text1=text
    text1=text.lower()
    a=text1.split(" ")
        
    dict={}
    for w in a:
        dict[w]=a.count(w)
    print(dict)
    return dict
#Do not modify code here...
dictionary_word = frequency_counter("Most students who start the MSIT program are not from Computer Science or Information Technology branches of engineering. Independent of that, almost all the students do not have the necessary CS background knowledge when they join MSIT. So, in CSPP1 the fundamental concepts in computer science are covered along with a very popular introductory programming language called python. Upon successful completion of this course, students will be able to read and write python programs.")
assert dictionary_word['of'] == 3
assert dictionary_word['cspp1'] == 1
assert dictionary_word['science'] == 2
assert dictionary_word['the'] == 4
assert dictionary_word['a'] == 1
assert dictionary_word['students'] == 3
assert dictionary_word['or'] == 1
assert dictionary_word['not'] == 2
assert dictionary_word['in'] == 2
assert dictionary_word['are'] == 2
print("All testcases passed")
