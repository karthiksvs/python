print("Welcome to *_*_*__*__ Bank")
print("Enter your credit card details")
a=int(input())
count=0
count1=0
while(a!=0):
    a=a/10
    count=count+1
    
if(count>=12):
        print("Enter the 4 digit pin you have given")
        b=int(input())
        if(b==int(1234)):
                print("Welcome ******")
        else:
                print("You have entered wrong pin")
else:
        print("Enter correct number")

print("choose your opyion")
print("1.Withdraw Savings")
print("2.Credit")
print("3.Check balance")
c=int(input())
d=int(1000000)
while(c>=1 and c<4):
    if(c==1):
        print("Enter the amount you want to withdraw")
        e=int(input())
        print("Available balance:",d)
        d=d-e
        print("After withdrawl amount is :",d)

    elif(c==2):
        print("Enter the card holder details to credit into his account")
        f=int(input())
        while(f!=0):
            f=int(f/10)
            count1=count1+1 
        if(count1>=12):
            print("Enter the amount")
            g=int(input())
            print("Amount transfered")
            d=d-g
            print("Remaining balance",d)
        else:
            print("Enter correct card number")
    elif(c==3):
        print("The balance is ",d)
    else:
        print("Select correct option")
    w='Y'
    print("do you want to exit Y/N")
    i=input()
    if(w==i):
        print("choose your opyion")
        print("1.Withdraw Savings")
        print("2.Credit")
        print("3.Check balance")
        c=int(input())
    else:
        exit(0)

