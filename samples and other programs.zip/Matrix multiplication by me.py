import zeros
zeros(3,4)
