s='Hello WOrld'
print(s[-2::2])
