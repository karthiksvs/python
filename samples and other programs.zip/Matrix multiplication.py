from array import *
X = [[1,2,3],[4 ,5,6],[7 ,8,9]]
Y = [[5,8,1],[6,7,3],[4,5,9]]
result = [[0,0,0],[0,0,0],[0,0,0]]
z=[[0,0,0],[0,0,0],[0,0,0]]
a=[[0,0,0],[0,0,0],[0,0,0]]
b=[[0,0,0],[0,0,0],[0,0,0]]
c=[[0,0,0],[0,0,0],[0,0,0]]

for i in range(len(X)):
   for j in range(len(Y[0])):
       for k in range(len(Y)):
           result[i][j] += X[i][k] * Y[k][j]
for i in range(len(X)):
   for j in range(len(X[i])):
         z[i][j] = X[i][j] + Y[i][j]
for i in range(len(X)):
   for j in range(len(X[i])):
         a[i][j] = X[i][j] - Y[i][j]
for i in range(len(X)):
   for j in range(len(X[i])):
         b[i][j] = X[i][j] / Y[i][j]
for i in range(len(X)):
   for j in range(len(X[i])):
         c[i][j] = X[i][j] % Y[i][j]
print("addition is :",z)
print("subraction is :",a)
print("Multiplication is :",result)
print("Division is :",b)
print("Modulus is :",c)

