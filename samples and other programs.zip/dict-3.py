def remove_duplicates(input):
  input=input.split()
  for i in range(0,len(input)):
    input[i]="".join(input[i])
  return input

assert remove_duplicates("Python is great and Java is also great") == "Python is great and Java also"
assert remove_duplicates("I felt happy because I saw the others were happy and because I knew I should feel happy, but I wasn’t really happy" == "I felt happy because saw the others were and knew should feel happy, but wasn’t really")
assert remove_duplicates("Even if they are djinns, I will get djinns that can outdjinn them" == "Even if they are djinns, I will get djinns that can outdjinn them")
assert remove_duplicates("Because the world is a place of silence, the sky at night when the birds have gone is a vast silent place" == "Because the world is a place of silence, sky at night when birds have gone vast silent")
assert remove_duplicates("There are some things that are so unforgivable that they make other things easily forgivable" == "There are some things that so unforgivable they make other easily forgivable")
print("All testcases are passed")
