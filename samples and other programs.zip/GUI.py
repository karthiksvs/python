from tkinter import *
a=Tk()
a.title("My window")
a.geometry("500X500")

