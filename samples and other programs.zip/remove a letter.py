print("Enter input")
a=input()
print("Enter deleted position")
n=int(input())
t=""
i=1
for c in a:
    if i!=n:
        t=t+c
    i=i+1

print(t)
