st="food | dairy | milk"
keys=st.split(" | ")
count=0
new_cat="eco" # should be added
d = t = {} # t is my temporary dictionary

for i in keys:
    t[i] = {}
    t = t[i]
    count=count+1
t[new_cat] = {}

print(d,count)
