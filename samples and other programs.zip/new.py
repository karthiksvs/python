a=10
b=input("Enter a number")
c=input("Enter a character")
print(a+int(b))
print("character is "+c)
input("press enter to quit")
