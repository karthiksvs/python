s1="name"
for i in range(1,5):
    list()
    print(i*i)

print(s1)

