a= int(input("Enter any number :"))
if(a%2==0):
    print(a,"Number is even")
else:
    print(a,"Number is odd")
