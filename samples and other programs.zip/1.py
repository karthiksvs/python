def str_a(cha):
  if(cha=='1' or cha=='2' or cha=='3'or cha=='4' or cha=='5' or cha=='6' or cha=='7' or cha=='8' or cha=='9' or cha=='0'):
    return True
  else:
    return False
def str_b(ch):
  if(ch.isdigit() or ch.isalpha()):
    return False
  else:
    return True
string = input("Enter an alpha-numeric string")
count=0
a=""
count1=0
b=0
max=0
for i in range(len(string)):
  message=str_a(string[i])
  if(message==True):
    count=count+1
  else:
    a=a+string[i]
print("count is:",count)
print("characters are:"+a)
j=len(string)
for i in range(len(string)):
  if(string[i]==string[j-1]):
    count1=count1+1
    j=j-1
  else:
    print("Not a Palindrome")
    break
if(count1==len(string)):
  print("Palindrome")
for i in range(len(string)):
  message=str_a(string[i])
  if(message==True):
    x=int(string[i])
    if(max<=x):
      max=x
print(max)
for i in range(len(string)):
  message=str_b(string[i])
  if(message==True):
      b=b+1
print(b)
#Write the functions
