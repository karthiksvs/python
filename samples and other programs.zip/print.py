def date_fashion(you, date):
  if(date%you==0 and you%date!=0):
    return 2
  elif(date%you==0 and you%date==0 and you<=5):
    return 1
  elif(date%you==0 and you%date==0 and you>5):
    return 2
  elif(date%you==0 and you%date==0 and you>5):
    return 2
  elif(date%you==0 and you%date!=0):
    return 2
  elif(you%date!=0 and you%date<1):
    return 1
  elif(you%date!=0):
    return 0
  else:
    return 0
  #Code
  pass

assert date_fashion(5, 10) == 2	
assert date_fashion(5, 2) == 0
assert date_fashion(5, 5) == 1
assert date_fashion(3, 3) == 1	
assert date_fashion(10, 2) == 0
assert date_fashion(2, 9) == 0	
assert date_fashion(9, 9) == 2
assert date_fashion(10, 5) == 2	
assert date_fashion(2, 2) == 0
assert date_fashion(3, 7) == 1
assert date_fashion(2, 7) == 0
assert date_fashion(6, 2) == 0
print("All the testcases are passed!")
