def sleep_in(weekday, vacation):
  if weekday==False or vacation==True:
    return True
  else:
    return False
  #Complete the code
  pass
assert sleep_in(False, False) == True
assert sleep_in(True, False) == False
assert sleep_in(False, True) == True
print("All the testcases passed!!!")
