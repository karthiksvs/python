from tkinter import *
mygui=Tk()
mygui.title("Hello")
mygui.geometry("500x500")
mygui.mainloop()
myLabel1=Label(text="Label one",fg="Red",bg="Yellow")
myLabel1.pack()
myButton1=Button(text="Button one",fg="Orange",bg="Yellow")
myButton1.pack()

