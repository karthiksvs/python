 n=len(a)
  m=len(b)
  if(m!=n):
    return False
  k=[False]*m_c
  i=[-1]*m_c
  for j in range(m):
    if(i[ord[a]]==-1):
      if(k[ord[b[j]]]==True):
        return False
      k[ord[b[j]]]==True
      i[ord[a]]==b
      
    elif( i[ord[a]]!=b):
      return False
  return True
#
