class sample:
    def __init__(self,name,age,hobby,college):
        self.name=name
        self.age=age
        self.hobby=hobby
        self.college=college
        print("name is {} age is {}".format(self.name,self.age))

class abc(sample):
    def __str__(self):
              return("college is {}  and hobbies are {}".format(self.college,self.hobby))
