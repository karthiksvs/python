import random
#from google.colab import files
x=[]
w=[]
lst1=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
def isWordGuessed(secretWord,lettersGuessed):
    y=secretWord
    m=list(y)
    if(m==x):
        return True
    else:
        return False

def getGuessedWord(secretWord,letterGuessed):
    if(letterGuessed in secretWord):
        for index in range(len(secretWord)):
            if(secretWord[index]==letterGuessed):
                #print(letterGuessed)
                x[index]=letterGuessed
                #print(x)
        return x
    else:
        return 0


def getAvailableLetters(lettersGuessed):
    if(letterGuessed in lst1):
        lst1.remove(letterGuessed)
        return lst1
    else:
        return "You have already gave that number"


print("Welcome to Hangman Game ")
n=8
a=open("Words.txt","r")
b=a.readlines()
lst=[]
d=[]
for line in b:
    lst.append(line[:-1])
c=random.choice(lst)
print(c)
for i in range(len(c)):
    x.append("_")
print("\n")
print("I am thinking of a number of length digits",len(c))
print("Available list is")
print(lst1)
for i in range(n):
    print("You have still guesses",n)
    letterGuessed=input("Please guess a letter:  ")
    d=getGuessedWord(c,letterGuessed)
    if(d==0):
        print("Letter not present in secretword")
        n=n-1
    else:
        print(d)
        e=getAvailableLetters(letterGuessed)
        print(e)
        f=isWordGuessed(c,letterGuessed)
        if(f==True):
            print("Congratulations , You Won")
            break
